# PaperDelta Mac return report

[简体中文](REPORT.zh-CN.md)

**Result: passed for the agreed native Mac development-preview scope.** Recommend
accepting the local candidate on the tested Apple Silicon Mac. No publication or
push occurred. Product runtime code and resources were not modified; the original
wheel remains the final tested package.

## Host, receipt and identity

- macOS 27.0.1, build 26A434; native hardware/process arm64. The independent hardware
  probes report `hw.optional.arm64=1`, `hw.machine=arm64`, `sysctl.proc_translated=0`.
- CPython 3.12.14 (existing bundled runtime) and 3.14.6 (existing Homebrew runtime).
  Git 2.51.0; Google Chrome 154.0.8037.97 on the real Mac, headless.
- All **1,060** transfer entries passed relative-path, symlink and SHA256 checks before
  edits. TRANSFER and BASELINE hashes are in [handoff.json](handoff.json) and the
  [receipt](evidence/build/mac-receipt/receipt.json).
- Windows source commit: `5ea7d27e28e5308f6ef3cf5ab4c7f807fb575f64`.
  Mac receipt commit: `722c0032d88ba2692f6737c48e86272dd293e735`.
  Repository-local noreply identity was used; global Git settings were unchanged.
- Original/final wheel: `paperdelta-0.2.0a1-py3-none-any.whl`, SHA256
  `c6f119ad4ded3e7866dd0f7efd233cac9466fd26cf9d9afe0eefdd7b6cf80c78`.
  All **32** runtime files/resources match the baseline, wheel and installed package.
  The **869** original frozen files checked remain unchanged.

## Actual runs

| Output directory under build/ | Python | Process exit | Passed / failures / errors / skipped |
| --- | --- | --- | --- |
| mac-validation-original-01 | 3.14.6 | 1 | No suite reached: dependency DNS failure |
| mac-validation-original-02 | 3.14.6 | 0 | 237 / 0 / 0 / 0 |
| mac-validation-py312-original-01 | 3.12.14 | 0 | 237 / 0 / 0 / 0 |
| mac-validation-final-py314-01 | 3.14.6 | 0 | 241 / 0 / 0 / 0 |
| mac-validation-final-py312-01 | 3.12.14 | 0 | 241 / 0 / 0 / 0 |

Four new validation-tool cases explain 237 → 241; existing tests were retained.
Both final environments were newly created, noneditable wheel installations.
The final suite JUnit files are [Python 3.14](evidence/build/mac-validation-final-py314-01/suite/3.14.6/junit.xml)
and [Python 3.12](evidence/build/mac-validation-final-py312-01/suite/3.12.14/junit.xml).
Both runs also passed bilingual core-only smoke tests, data-only detection, Ruff
lint/format, examples and local Git CI scenarios. POSIX cases ran without skips.

Every platform invocation used this argument sequence, with the actual interpreter
and fresh output directory listed in [commands.json](evidence/commands.json):

```sh
python tools/validate_platform.py --wheel install/paperdelta-0.2.0a1-py3-none-any.whl --out build/RUN_DIRECTORY --require-system Darwin --expected-arch arm64
```

Additional commands were `python tools/demo.py --out build/mac-demo-01`, the authored
`build/mac-first-use/run_first_use.py`, and
`node tools/report_browser_qa.cjs build/mac-demo-01/comparison-reversed/review/report.html build/mac-browser-fixed-01 --with-figure`.
All final commands exited 0; the initial walkthrough recorder exited 1 as detailed below.
Full executable paths, arguments, environment overrides and process exits are retained
in command evidence. `python tools/check_docs.py` passed **30 pairs / 61 pages /
561 local links**. Final Ruff checks, `git diff --check` and four core/full `pip check`
commands exited 0 ([final checks](evidence/build/mac-final-checks/evidence.json)).

## First-user assessment

The installed Python 3.14 wheel completed **32 recorded CLI/PTY commands** in the
successful authored walkthrough: both languages for help/doctor/check, all language
priority levels, six passing example bindings, and data-only mismatch detection.
A real Chinese POSIX terminal accepted ten bindings in Unicode paths while preserving
model ID `001`. Construction cancellation, final cancellation and the state before
explicit final confirmation were checked for zero writes. Ten edits were previewed,
applied, rechecked and recovered to the original UTF-8 BOM/CRLF bytes. Location repair
preserved full typed source/metric/unit/display/claim definitions and other input bytes.
Real stdio MCP listed 13 read-only tools and checked the project without writes.
See [walkthrough](evidence/build/mac-first-use/02/evidence.json) and its transcripts.
Independent participants: **zero**; these are developer-authored automated inputs.

Chrome passed both languages, five filters, bilingual search, expanded evidence,
state/focus retention, Enter/Tab keyboard checks, no-JavaScript reading, desktop
1365×1000 and narrow 375×812 layouts. External requests: **0**; script errors: **0**;
horizontal overflow: **none**. Chinese desktop and narrow screenshots were inspected.
See [browser evidence](evidence/build/mac-browser-fixed-01/evidence.json) and
[Chinese preview](evidence/build/mac-browser-fixed-01/report-preview.zh-CN.png).

## Changes and preserved failures

1. `tools/validate_platform.py`: denied/absent Rosetta probes previously became
   `false`; now retain exit/stdout/stderr and report unknown as `null`. Four new
   regressions cover native, translated, absent and denied results. The original
   sandbox probe denial and later successful native probe are both retained.
2. `tools/report_browser_qa.cjs`: replace the hard-coded Windows description with
   actual OS/kernel/architecture/Node metadata, and check focus and keyboard behavior.
   The original browser run passed its functional assertions but its host description
   is wrong; use the corrected record. Neither run used a Windows browser.
3. The first dependency installation failed because the sandbox could not resolve
   PyPI. A fresh authorized native run with network access succeeded. No product fix
   was required, and the failed installation log was not overwritten.
4. The first authored walkthrough recorder compared raw YAML after default fields
   were serialized. It failed despite equal typed scientific definitions. The original
   script, traceback and [diagnosis](evidence/build/mac-first-use/01/assertion-diagnosis.json)
   are retained. The corrected recorder compares complete typed definitions and also
   checks unchanged non-configuration bytes; the full rerun passed.
5. Synchronized English/Chinese README, Mac guide, acceptance/progress/plan and language
   pages; added a paired dated Mac acceptance page and a new evidence summary.

There are **21 changed/new files**, no deletions. Runtime code is unchanged, so no new
wheel was necessary: the matching original wheel was revalidated in two fresh native
environments. [Wheel identities](artifacts/wheel-hashes.json) reference the existing
package; this return does not duplicate it. The original handoff manifests, licenses
and frozen studies remain untouched.

## Limits and Windows review

No unresolved issue remains within the agreed local scope. Untested: Intel Mac,
Python 3.11/3.13 on Mac, other macOS versions, Safari/Firefox, remote CI, independent
users, power-loss/network filesystems, and fresh Windows/Linux runs of these tool
changes. Historical corpus/model limitations remain unchanged; see
[unresolved.json](unresolved.json). No general scientific or model-quality claim follows.

`changes.patch` is a binary/full-index diff against the Mac receipt baseline and was
successfully applied in an isolated Git index; all 21 resulting file hashes matched.
`changed-files.json` records before/after hashes; `changed-files/` holds the exact new
bytes and `deleted-files.json` is empty. Check those before hashes against the Windows
checkout before applying, since the handoff included documentation overlays.

Evidence retains project-relative hierarchy. Public text replaces checkout/home/user
and JUnit hostname values with placeholders; HTML/XML placeholders are escaped.
[PROVENANCE.json](evidence/PROVENANCE.json) records each original/public hash. Original
raw logs remain on the Mac. No Git history, environments, caches, keys, models or full
project copy is included. `MANIFEST.json` hashes every return file except itself.

Copy **only the ZIP and matching .zip.sha256** to Windows
`build/mac-return-inbox/`. Verify the ZIP SHA256, then have the original conversation
review identities, failures, evidence and patch before merging. Nothing was uploaded.
