# PaperDelta Mac 回传报告

[English](REPORT.en.md)

**结果：通过本轮约定的原生 Mac 开发预览版验收，建议接受本机候选。**
没有发布或推送。产品运行代码和资源未修改；原 wheel 即最终实际测试的安装包。

## 本机、接收与身份

- macOS 27.0.1，构建 26A434；硬件和进程均为原生 arm64。独立查询记录
  `hw.optional.arm64=1`、`hw.machine=arm64`、`sysctl.proc_translated=0`。
- CPython 3.12.14（已有应用运行时）和 3.14.6（已有 Homebrew）；Git 2.51.0。
  在真实 Mac 上无头运行 Google Chrome 154.0.8037.97。
- 编辑前 **1,060** 个清单文件全部通过相对路径、符号链接和 SHA256 检查。
  TRANSFER/BASELINE 自身哈希见 [handoff.json](handoff.json)及[接收记录](evidence/build/mac-receipt/receipt.json)。
- Windows 源提交：`5ea7d27e28e5308f6ef3cf5ab4c7f807fb575f64`；
  Mac 接收提交：`722c0032d88ba2692f6737c48e86272dd293e735`。
  只使用仓库局部 noreply Git 身份，未修改全局配置。
- 原/最终 wheel：`paperdelta-0.2.0a1-py3-none-any.whl`，SHA256 为
  `c6f119ad4ded3e7866dd0f7efd233cac9466fd26cf9d9afe0eefdd7b6cf80c78`。
  **32** 个运行文件/资源与基线、wheel、实际安装内容一致；核对的 **869** 个原冻结文件未改变。

## 实际执行

| build/ 下的输出目录 | Python | 进程退出码 | 通过 / 失败 / 错误 / 跳过 |
| --- | --- | --- | --- |
| mac-validation-original-01 | 3.14.6 | 1 | 未进入测试：依赖下载 DNS 失败 |
| mac-validation-original-02 | 3.14.6 | 0 | 237 / 0 / 0 / 0 |
| mac-validation-py312-original-01 | 3.12.14 | 0 | 237 / 0 / 0 / 0 |
| mac-validation-final-py314-01 | 3.14.6 | 0 | 241 / 0 / 0 / 0 |
| mac-validation-final-py312-01 | 3.12.14 | 0 | 241 / 0 / 0 / 0 |

237 → 241 来自四项新增验证工具回归；原测试未删除。最终两套环境均全新创建、
安装实际 wheel，未用 editable 结果替代。最终 JUnit：[Python 3.14](evidence/build/mac-validation-final-py314-01/suite/3.14.6/junit.xml)、
[Python 3.12](evidence/build/mac-validation-final-py312-01/suite/3.12.14/junit.xml)。
两套均通过双语纯核心冒烟、仅数据变化诊断、Ruff 检查/格式、样例及本地 Git CI
场景；POSIX 专用测试全部执行，零跳过。

每次平台验证使用以下参数，真实解释器、独立目录和退出码见
[commands.json](evidence/commands.json)：

```sh
python tools/validate_platform.py --wheel install/paperdelta-0.2.0a1-py3-none-any.whl --out build/RUN_DIRECTORY --require-system Darwin --expected-arch arm64
```

其他实际命令包括 `python tools/demo.py --out build/mac-demo-01`、自编
`build/mac-first-use/run_first_use.py`，以及
`node tools/report_browser_qa.cjs build/mac-demo-01/comparison-reversed/review/report.html build/mac-browser-fixed-01 --with-figure`。
最终命令全部退出 0；首次体验记录器退出 1，原因见下文。证据保留实际可执行路径、
参数、必要环境覆盖和退出码。`python tools/check_docs.py` 通过 **30 对 / 61 页面 /
561 个本地链接**；最终 Ruff、`git diff --check` 和四套核心/完整环境的
`pip check` 均退出 0，见[最终检查](evidence/build/mac-final-checks/evidence.json)。

## 开发者与第一位使用者验收

成功体验包含 **32 条实际 CLI/PTY 命令记录**：中英文 help/doctor/check、全部语言
优先级、六处样例绑定通过和仅数据变化诊断。真实中文 POSIX 终端在 Unicode 路径
中完成十处绑定，保留模型 ID `001`；构造取消、最终取消及明确确认前均核对无写入。
十处修改完成预览、应用、重查和 UTF-8 BOM/CRLF 原字节恢复。位置修复保留完整
类型化来源/指标/单位/显示/结论定义及其他输入字节。真实 stdio MCP 列出十三个
只读工具，并完成无写入检查。见[体验记录](evidence/build/mac-first-use/02/evidence.json)及终端日志。
独立真人 **0 人**；这些是开发者编写并驱动的自动输入。

Chrome 通过两种语言、五类筛选、双语搜索、证据展开、状态/焦点保留、Enter/Tab
键盘操作、无 JavaScript 阅读、1365×1000 桌面及 375×812 窄屏。外部请求 **0**、
脚本错误 **0**、横向溢出 **无**。已目视检查中文桌面和窄屏截图。
见[浏览器记录](evidence/build/mac-browser-fixed-01/evidence.json)及
[中文预览](evidence/build/mac-browser-fixed-01/report-preview.zh-CN.png)。

## 修改与保留的失败

1. `tools/validate_platform.py`：原先 Rosetta 查询受限/缺失会被记作 `false`；现保留
   退出码/输出/错误，未知记为 `null`。四项回归覆盖原生、转译、缺失和拒绝访问。
   最初沙箱查询失败及后来原生查询成功的原记录都保留。
2. `tools/report_browser_qa.cjs`：去掉写死的 Windows 描述，记录实际系统/内核/架构/
   Node，并检查焦点和键盘行为。原浏览器功能断言通过，但主机描述错误；应以后续
   记录为准。两次实际使用的都是 Mac 浏览器。
3. 首次依赖安装因沙箱不能解析 PyPI 失败。在已有授权范围内允许网络访问后，使用
   新目录重试通过。无须产品修复，原失败日志未覆盖。
4. 首次补充体验记录器在默认字段展开后比较原始 YAML 字典，产生错误断言，实际
   类型化科学定义一致。原脚本、堆栈及[诊断](evidence/build/mac-first-use/01/assertion-diagnosis.json)保留。
   修正为比较完整类型化定义，并额外核对所有非配置文件字节后，完整流程复跑通过。
5. 同步中英文 README、Mac 指南、验收/进展/计划和语言页；新增成对的日期验收页
   及单独证据摘要。

共 **21 个修改/新增文件**，无删除。产品运行代码未变，因此无须新建 wheel；在两套
全新原生环境中重验了匹配的原包。[安装包身份](artifacts/wheel-hashes.json)引用原包，
回传中不重复附带 wheel。原交接清单、许可证和冻结研究记录保持原字节。

## 未测范围与 Windows 审查

本轮约定本机范围内无未解决事项。未测：Intel Mac、Mac Python 3.11/3.13、其他
macOS、Safari/Firefox、远程 CI、独立真人、断电/网络文件系统，以及这些工具修改
后的新一轮 Windows/Linux 执行。历史语料和模型限制不变，见[未测与未解决事项](unresolved.json)。
不据此推断一般科学正确性或模型质量。

`changes.patch` 是相对 Mac 接收基线的完整索引二进制 diff，已在独立 Git 索引中
成功应用，重建的 21 个文件哈希全部一致。`changed-files.json` 记录前后哈希，
`changed-files/` 保存修改后原字节，`deleted-files.json` 为空。交接版本包含文档
覆盖层，在 Windows 应先核对修改前哈希，再审查应用。

证据保留项目相对层级。公开文本替换项目路径、主目录、用户名及 JUnit 主机名，
HTML/XML 占位符经过实体转义。[来源索引](evidence/PROVENANCE.json)列出原/公开哈希，
本机原日志仍保留。不含 Git 历史、环境、缓存、密钥、模型或完整项目副本。
`MANIFEST.json` 记录除自身外的所有回传文件哈希。

请只复制 **ZIP 和对应 .zip.sha256 两个文件**到 Windows 原项目
`build/mac-return-inbox/`，核对 ZIP 校验值后，请原对话审查身份、失败记录、证据和
补丁，再合并。本轮没有向外部上传。
